<div style=" padding: 20px;">

    <div class="container"
        style="padding-top: 100px!important; background-color: tan; background-image: url('path/to/your/image.jpg'); background-size: cover; background-position: center;">
        <h2>Add New Election</h2>
        <div class="container">
            <form action="../api/election.php" method="post">
                <div class="form-group">
                    <label for="name">Election Name:</label>
                    <input type="text" class="form-control" id="name" name="name" style="width: 100%;" required>
                </div>
                <div class="form-group">
                    <label for="from_date">From Date:</label>
                    <input type="date" class="form-control" id="from_date" name="from_date" required>
                </div>
                <div class="form-group">
                    <label for="to_date">To Date:</label>
                    <input type="date" class="form-control" id="to_date" name="to_date" required>
                </div>
                <div class="form-group">
                    <label for="max_candidate">Maximum candidates allowed:</label>
                    <input type="number" max="99" class="form-control" id="max_candidate" name="max_candidate" required>
                </div>
                <div class="form-group">
                    <label for="location">Location:</label>
                    <textarea class="form-control" id="location" name="location" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Add Election</button>
            </form>
        </div>
    </div><br>

    <div class="container">
        <h1>Upcoming election</h1>
        <table class="table table-dark" border="4px">
            <thead>
                <tr>
                    <th scope="col">S No.</th>
                    <th scope="col">Election Name</th>
                    <th scope="col">Start date</th>
                    <th scope="col">Ending date</th>
                    <th scope="col">No of Candidate</th>
                    <th scope="col">Location</th>
                </tr>
            </thead>
            <tbody id="result">
                <?php
                include("../api/connect.php");
                $query = "SELECT * FROM election";
                $result = mysqli_query($connect, $query);
                $sno = 0;
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $sno++;
                        echo "<tr>";
                        echo "<td>" . $sno . "</td>";
                        echo "<td>" . $row["name"] . "</td>";
                        echo "<td>" . $row["from_date"] . "</td>";
                        echo "<td>" . $row["to_date"] . "</td>";
                        echo "<td>" . $row["max_candidate"] . "</td>";
                        echo "<td>" . $row["location"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    die("Query failed: " . mysqli_error($connect));
                }
                ?>
            </tbody>
        </table>
    </div>

</div>