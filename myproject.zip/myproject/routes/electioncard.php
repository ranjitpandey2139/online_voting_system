<div class='' style="display:flex; justify-content: center; gap: 5px;flex-wrap: wrap;width:100%;margin-top: 90px;">
    <?php
    include("../api/connect.php");
    $query = "SELECT * FROM election WHERE CURDATE() BETWEEN from_date AND to_date";
    $result = mysqli_query($connect, $query);
    $sno = 0;
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '
            <div class="card" style="width: 18rem; background-color: #999933;">
                <div class="card-body">
                <h5 style="color: blue;">Election name</h5> <h5 class="card-title">' . $row["name"] . '</h5>
                <h5 style="color: blue;">Start Date</h5>  <p class="card-text">' . $row["from_date"] . '</p>
                <h5 style="color: blue;">End Date</h5>   <p class="card-text">' . $row["to_date"] . '</p>
                <h5 style="color: blue;">No Of Candidate</h5><p class="card-text">' . $row["max_candidate"] . '</p>
                <h5 style="color: blue;">Location</h5>  <p class="card-text">' . $row["location"] . '</p>
                    <a href="./index.php?page=voter&election=' . $row['id'] . '" class="btn btn-primary">GO TO VOTE</a>
                </div>
            </div>
            ';
        }
    } else {
        die("Query failed: " . mysqli_error($connect));
    }
    ?>
</div>