<div style="padding: 20px;">
  <div class="container"
    style="padding-top: 100px!important; background-color: tan; background-image: url('path/to/your/image.jpg'); background-size: cover; background-position: center;">
    <h2>Result</h2>
    <table class="table align-middle mb-0 bg-white">
      <thead class="bg-light">
        <tr>
          <th>Si.no</th>
          <th>Candidate Name</th>
          <th>Candidate Image</th>
          <th>No of votes</th>
        </tr>
      </thead>
      <tbody id="result">
        <?php
        include("../api/connect.php");
     
        $election = $_GET['election'];
        $query = "SELECT
        u.id AS id,
        COUNT(e.id) AS count,
        u.name AS candidate_name,
        u.photo
    FROM user AS u
    LEFT JOIN votings AS e ON (e.election_Id = u.election AND e.candidate_Id = u.id)              
    WHERE u.role = 'candidate' AND u.election = '$election'
    GROUP BY u.id ORDER BY count DESC";
        $result = mysqli_query($connect, $query);
        $sno = 0;

        if ($result) {
          while ($row = mysqli_fetch_assoc($result)) {
            $sno++;
            echo "<tr>";
            echo "<td>" . $sno . "</td>";
            echo "<td>" . $row["candidate_name"] . "</td>";
            echo "<td><img src='http://localhost/myproject/uploads/" . $row["photo"] . "' alt='Image' style='width: 25px; height: 25px; border-radius: 50%;'></td>";
            echo "<td>" . $row["count"] . "</td>";
            echo "</tr>";
          }
        } else {
          die("Query failed: " . mysqli_error($connect));
        }
        ?>
      </tbody>
    </table>
  </div>
</div>