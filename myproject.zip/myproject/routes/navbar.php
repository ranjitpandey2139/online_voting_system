<div class="section1">
    <nav class="navbar navbar-expand-lg navbar-light px-5 fixed-top" style="background-color: #e8a746;">
        <a class="navbar-brand" href="#">
            <img src="../Assets/cards/vote_logo.jpg" alt="logo" style="height: 50px; border-radius: 10px;">
        </a>
        <a class="navbar-brand" href="#">Online Voting System</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php?page=home">Home <span class="sr-only">(current)</span></a>
                </li>
                <?php
                session_start(); // Call session_start() once at the beginning
                if (isset($_SESSION["role"]) && $_SESSION["role"] == 'admin') {
                    echo '
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=candidate">Candidate</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=addelection">Election panel </a>
                    </li>
                    ';
                }
                if (isset($_SESSION['id'])) {
                    echo '
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?page=electioncard">Voter</a>
                    </li>
                    ';
                }
                ?>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="" id="navbarDropdownMenuLink" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                        Action
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                        <?php
                        // Remove the session_start() here
                        if (!isset($_SESSION['id'])) {
                            echo '
                                <a class="dropdown-item" href="index.php?page=register">SignUp</a>
                                <a class="dropdown-item" href="index.php?page=login">Log in</a>
                                ';
                        } else {
                            echo '
                                <a class="dropdown-item" href="../api/logout.php">Log out</a>
                                ';
                        }
                        ?>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</div>