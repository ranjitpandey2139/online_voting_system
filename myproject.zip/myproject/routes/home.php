<div style=" padding: 20px;">
    <div class="section2">
        <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="../Assets/cards/parliament.jpg" alt="First slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color: rgb(245, 143, 10);">Systematic Voters Education and Electoral Participation
                        </h1>
                        <p style="color: hsl(81, 88%, 50%); font-size: 25px; width: 1000px;">Systematic Voters’
                            Education and
                            Electoral Participation program, better known as SVEEP, is
                            the flagship program of the Election Commission of India for voter education, spreading
                            voter awareness and promoting voter literacy in India. Since 2009, we have been working
                            towards preparing India’s electors and equipping them with basic knowledge related to the
                            electoral process.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100"
                        src="../Assets/cards/democracy.jpg"
                        alt="Second slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color: aqua;">India International Institute of Democracy and Election Management</h1>
                        <p style="color: #f00dbf; font-size: 25px; width: 1000px;">The Election Commission of India
                            (ECI), established the India International Institute of Democracy and Election Management
                            (IIIDEM) to advance its professional competence in election management, promote peoples
                            participation, contribute to developing stronger democratic institutions and support the
                            efforts of ECI in carrying out its mandate and functions.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100"
                        src="../Assets/cards/iindia.jpg"
                        alt="Third slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 style="color: rgb(98, 238, 161);">About ECI</h1>
                        <p style="color: #f5f10e; font-size: 25px; width: 1000px;">
                            The Election Commission of India is an autonomous constitutional authority responsible for
                            administering Union and State election processes in India. The body administers elections to
                            the Lok Sabha, Rajya Sabha, State Legislative Assemblies in India, and the offices of the
                            President and Vice President in the country.
                        </p>
                    </div>
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <div class="row mt-4 card-parent">
        <div class="col-sm-3 mb-3">
            <div class="card">
                <img src="../Assets/cards/vote-photos.png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Go to Vote</h5>
                    <p class="card-text">If you are want to vote please visite the website</p>
                    <a href="#" class="btn btn-primary">click here</a>
                </div>
            </div>
        </div>
        <div class="col-sm-3 mb-3">
            <div class="card">
                <img src="../Assets/cards/OIP.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Election information</h5>
                    <p class="card-text">Election information is given here plese visite this link</p>
                    <a href="#" class="btn btn-primary">click here</a>
                </div>
            </div>
        </div>
        <div class="col-sm-3 mb-3">
            <div class="card">
                <img src="../Assets/cards/election-voting.avif" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Candidate Form</h5>
                    <p class="card-text">If you want to stand in the election then click on this link</p>
                    <a href=".\routes\Candidateform.php" class="btn btn-primary">Go somewhere</a>
                </div>
            </div>
        </div>
        <div class="col-sm-3 mb-3">
            <div class="card">
                <img src="../Assets/cards/voter.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Election Result</h5>
                    <p class="card-text">If you are intrested see the election result then clikc (click here)</p>
                    <a href="index.php?page=resultcard" class="btn btn-primary">click here</a>
                </div>
            </div>
        </div>
    </div>

</div>