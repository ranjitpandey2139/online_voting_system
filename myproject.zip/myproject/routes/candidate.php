<div style=" padding: 20px;">

    <div class="container"
        style="padding-top: 100px!important; background-color: tan; background-image: url('path/to/your/image.jpg'); background-size: cover; background-position: center;">
        <h2>Add New Candidate</h2>
        <div class="container">
            <form action="../api/candidate.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <select name="election" class="form-control" id="election" style="width: 100%; height: 10%;"
                        required>
                        <option value="">Select Election</option>
                        <?php
                        include("../api/connect.php");
                        $query = "SELECT * FROM election";
                        $result = mysqli_query($connect, $query);
                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value=" . $row['id'] . ">" . $row['name'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="Name">Candidate Name:</label>
                    <input type="text" class="form-control" id="Name" name="Name" style="width: 100%;" required>
                </div>
                <div class="form-group">
                    <label for="mobile">Phone Number:</label>
                    <input class="form-control" type="number" name="mobile" placeholder="Enter mobile" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input class="form-control" type="password" name="password" placeholder="password" required>
                </div>
                <div class="form-group">
                    <label for="photo">Candidate Photo:</label>
                    <input type="file" class="form-control" id="photo" name="photo" style="width: 100%;" required>
                </div>
                <button type="submit" class="btn btn-primary">Add Candidate</button>
            </form>
        </div>
    </div><br>

    <div class="container">
        <h3>Candidate Details</h3>

        <table class="table table-dark" border="4px">
            <thead>
                <tr>
                    <th scope="col">Si.no</th>
                    <th scope="col">Candidate Name</th>
                    <th scope="col">Election Name</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Candidate Image</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody id="result">
                <?php
                include("../api/connect.php");
                function deleteRow($rowId)
                {
                    global $connect;
                    $sql = "DELETE FROM user WHERE id = '$rowId'";
                    $result = mysqli_query($connect, $sql);
                    if ($result) {
                        echo '<script>
                    window.alert("Candidate deleted successfully!");
                    window.location = "./routes/index.php?page=candidate";
                    </script>';
                    } else {
                        echo '
                    <script>
                        alert("Error: ' . mysqli_error($connect) . '");
                        window.location = "./routes/index.php?page=candidate";
                    </script>';
                    }
                }
                if (array_key_exists('deleteId', $_POST)) {
                    $rowID = $_POST['deleteId'];
                    deleteRow($rowID);
                }
                $query = "SELECT
                u.id as id,
                e.name AS election_name,
                u.name AS candidate_name,
                u.mobile,
                u.photo
            FROM user AS u
            INNER JOIN `election` AS e ON e.id = u.election
            WHERE u.role = 'candidate'";
                $result = mysqli_query($connect, $query);
                $sno = 0;
                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $sno++;
                        echo "<tr>";
                        echo "<td>" . $sno . "</td>";
                        echo "<td>" . $row["candidate_name"] . "</td>";
                        echo "<td>" . $row["election_name"] . "</td>";
                        echo "<td>" . $row["mobile"] . "</td>";
                        echo "<td><img src='http://localhost/myproject/uploads/" . $row["photo"] . "' alt='Image' style='width: 25px; height: 25px; border-radius: 50%;'></td>";
                        echo '<td>
                        <form method="post"> 
                            <input type="hidden" name="deleteId" value="' . $row["id"] . '" />
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form> 
                        </td>';
                        echo "</tr>";
                    }
                } else {
                    die("Query failed: " . mysqli_error($connect));
                }
                ?>
            </tbody>
        </table>
    </div>

</div>