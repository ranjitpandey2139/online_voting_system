<div style="padding: 20px;">
  <div class="container"
    style="padding-top: 100px!important; background-color: tan; background-image: url('path/to/your/image.jpg'); background-size: cover; background-position: center;">
    <h2>Voting panel</h2>
    <table class="table align-middle mb-0 bg-white">
      <thead class="bg-light">
        <tr>
          <th>Si.no</th>
          <th>Election Name</th>
          <th>Candidate Name</th>
          <th>Candidate Image</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody id="result">
        <?php
        include("../api/connect.php");
        if (session_status() == PHP_SESSION_NONE) {
          session_start();
      }
      
        function voteCandidate($candidateId, $voterID, $electionID)
        {
          global $connect;
          $getPrevVote = "SELECT id FROM votings WHERE election_Id = '$electionID' AND voters_Id = '$voterID'";
          $prevVote = mysqli_query($connect, $getPrevVote);
          if (mysqli_num_rows($prevVote) > 0) {
            echo '<script>
                    window.alert("You can cast only one vote !");
                  </script>';
          } else {
            $sql = "INSERT INTO votings (election_Id, voters_Id, candidate_Id) VALUES ($electionID,$voterID,$candidateId)";
            $result = mysqli_query($connect, $sql);
            if ($result) {
              echo '<script>
                    window.alert("Vote cast successfully!");
                    window.location = "./routes/index.php?page=electioncard";
                  </script>';
            } else {
              echo '<script>
                    alert("Error: ' . mysqli_error($connect) . '");
                    window.location = "./routes/index.php?page=candidate";
                  </script>';
            }
          }
        }
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['candidate_id']) && isset($_POST['election_id']) && isset($_SESSION["id"])) {
          $candidateID = $_POST['candidate_id'];
          $electionID = $_POST['election_id'];
          $voterID = $_SESSION['id'];
          voteCandidate($candidateID, $voterID, $electionID);
        }
        $election = $_GET['election'];
        $query = "SELECT
                    u.id AS id,
                    e.id AS election_id,
                    e.name AS election_name,
                    u.name AS candidate_name,
                    u.photo
                FROM user AS u
                INNER JOIN `election` AS e ON e.id = u.election
                WHERE u.role = 'candidate' AND u.election = '$election'";
        $result = mysqli_query($connect, $query);
        $sno = 0;

        if ($result) {
          while ($row = mysqli_fetch_assoc($result)) {
            $sno++;
            echo "<tr>";
            echo "<td>" . $sno . "</td>";
            echo "<td>" . $row["election_name"] . "</td>";
            echo "<td>" . $row["candidate_name"] . "</td>";
            echo "<td><img src='http://localhost/myproject/uploads/" . $row["photo"] . "' alt='Image' style='width: 25px; height: 25px; border-radius: 50%;'></td>";
            echo '<td>
                    <form method="POST"> 
                      <input type="hidden" name="candidate_id" value="' . $row["id"] . '" />
                      <input type="hidden" name="election_id" value="' . $row["election_id"] . '" />
                      <button type="submit" class="btn btn-danger">Vote</button>
                    </form> 
                  </td>';
            echo "</tr>";
          }
        } else {
          die("Query failed: " . mysqli_error($connect));
        }
        ?>
      </tbody>
    </table>
  </div>
</div>