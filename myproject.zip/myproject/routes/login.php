<?php
session_start();
if (isset($_SESSION['name'])) {
    header("Location: ./routes/index.php?page=home");
    exit();
}
?>

<hr>

<div class="cover1">
    <div class="box1">
        <h1>Online Voting System</h1>
        <h1>Login</h1><br>
        <form action="../api/login.php" method="POST">
            <input class="form-control" type="number" name="mobile" placeholder="Enter mobile"><br>
            <input class="form-control" type="password" name="password" placeholder="Enter password"><br>
            <button style="padding: 5px; font-size: 15px; background-color: darkblue; color: white; border-radius: 5px;">
                Login
            </button><br><br>
            New user? <a href="index.php?page=register" style="color: aqua;">Register Here</a>
        </form>
    </div>
</div>
