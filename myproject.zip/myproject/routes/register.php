<div class="cover">
    <div class="box">
        <!-- <h1>Online Voting System</h1> -->
        <h3>Registration</h3><br>
        <form action="./api/register.php" method="POST" enctype="multipart/form-data">
            <input class="form-control" type="text" name="Name" placeholder="Enter Name" required><br>
            <input class="form-control" type="number" name="mobile" placeholder="Enter mobile" required><br>
            <input class="form-control" type="password" name="password" placeholder="password" required><br>
            <input class="form-control" type="password" name="cpassword" placeholder="confirm password" required><br>
            <input class="form-control" type="text" name="address" placeholder="Address" required><br>
            <div class="mb-3">
                <input class="form-control" type="file" name="photo" required>
            </div>
            <button
                style="padding: 5px; font-size: 15px; background-color: darkblue; color: white; border-radius: 5px;">Register</button><br><br>
            Already user? <a href="index.php?page=login" style="color: aqua;">Login here</a>
        </form>
    </div>
</div>