<footer class="bg-dark text-white mt-5">
    <div class="container py-4">
        <div class="row">
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <p>Email: pandeyranjit2139@gmail.com</p>
                <p>Phone: +91 8974837576</p>
            </div>
            <div class="col-md-4">
                <h5>Follow Us</h5>
                <ul class="list-unstyled">
                    <li><a href="https://www.facebook.com/pandey.ranjit" class="text-white">Facebook</a></li>
                    <li><a href="https://twitter.com/@PandeyRanj95068" class="text-white">Twitter</a></li>
                    <li><a href="https://www.instagram.com/?hl=en" class="text-white">Instagram</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="" class="text-white">Privacy Policy</a></li>
                    <li><a href="" class="text-white">Terms of Service</a></li>
                    <li><a href="" class="text-white">FAQ</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="text-center py-3" style="background-color: #333;">
        <p class="mb-0">&copy; 2024 Online Voting System. All rights reserved.</p>
    </div>
</footer>