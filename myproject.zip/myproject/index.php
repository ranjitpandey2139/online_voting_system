<?php
echo '
    <script>
        window.location = "./routes/index.php?page=home";
    </script>
        ';

?>