<?php
include("connect.php");
$mobile = $_POST['mobile'];
$password = $_POST['password'];
$query = "SELECT * FROM user WHERE mobile = '$mobile' LIMIT 1";
$result = $connect->query($query);
$user = $result->fetch_assoc();
if (isset($user)) {
    if (password_verify($password, $user['password'])) {
        session_start();
        $_SESSION['mobile'] = $user['mobile'];
        $_SESSION['id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];
        echo '
        <script>
            window.alert("User loggedin!");
            window.location = "../routes/index.php?page=home";
        </script>
        ';
    } else {
        echo '
        <script>
            window.alert("Password Incorrect");
            window.location = "../routes/index.php?page=login";
        </script>
        ';
    }
} else {
    echo '
    <script>
        window.alert("Incorrect mobile number");
        window.location = "../routes/index.php?page=login";
    </script>
    ';
}

?>