<?php
include("connect.php");
$name = $_POST['Name'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];
$address = $_POST['address'];
$image = $_FILES['photo']['name'];
$tmp_name = $_FILES['photo']['tmp_name'];
$role = "voter";

if ($password === $cpassword) {
    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    move_uploaded_file($tmp_name, "../uploads/$image");
    $query = "INSERT INTO user (name, mobile, password, address, photo, role, status) VALUES ('$name', '$mobile', '$hashed_password', '$address', '$image', '$role', 0)";
    $insert = mysqli_query($connect, $query);
    if ($insert) {
        echo '
        <script>
            alert("Registration successful!");
            window.location = "../routes/index.php?page=login";
        </script>
        ';
    } else {
        echo '
        <script>
            alert("Some error occurred!");
            window.location = "../routes/index.php?page=register";
        </script>
        ';
    }

} else {
    echo '
    <script>
        alert("Password and confirm password do not match!");
        window.location = "../routes/index.php?page=register";
    </script>
    
    ';

}
?>