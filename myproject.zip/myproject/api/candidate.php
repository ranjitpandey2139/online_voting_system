<?php
include("connect.php");
$election = $_POST['election'];
$name = $_POST['Name'];
$mobile = $_POST['mobile'];
$password = $_POST['password'];
$image = $_FILES['photo']['name'];
$tmp_name = $_FILES['photo']['tmp_name'];
$role = "candidate";

move_uploaded_file($tmp_name, "../uploads/$image");

if ($election && $name && $mobile && $password && $image) {
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $query = "INSERT INTO user (name, mobile, password, photo, election, role, status) 
            VALUES ('$name', '$mobile', '$hashed_password', '$image', '$election', '$role', 0)";
    $insert = mysqli_query($connect, $query);
    if ($insert) {
        echo '
        <script>
            window.alert("Candidate created successfully!");
            window.location = "../routes/index.php?page=candidate";
        </script>
        ';
    } else {
        echo '
        <script>
            alert("Error: ' . mysqli_error($connect) . '");
            window.location = "../routes/index.php?page=candidate";
        </script>
        ';
    }
} else {
    echo '
        <script>
            alert("Fill all required fields.");
            window.location = "../routes/index.php?page=candidate";
        </script>
        ';
}

?>