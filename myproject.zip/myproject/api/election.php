<?php
include("connect.php");
$name = $_POST['name'];
$from_date = $_POST['from_date'];
$to_date = $_POST['to_date'];
$location = $_POST['location'];
$max_candidate = $_POST['max_candidate'];

$query = "INSERT INTO election (name, from_date, to_date, location,max_candidate) VALUES ('$name', '$from_date', '$to_date', '$location','$max_candidate')";
$insert = mysqli_query($connect, $query);
if ($insert) {
    echo '
        <script>
            window.alert("Election Created successfull!");
            window.location = "../routes/index.php?page=addelection";
        </script>
        ';
} else {
    echo '
        <script>
            window.alert("some errored!");
            window.location = "../routes/index.php?page=addelection";
        </script>
        ';
}

?>