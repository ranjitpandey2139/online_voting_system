<?php
session_start();
$_SESSION = array();
session_destroy();
if (!isset($_SESSION["name"])) {
    echo '
        <script>
            window.alert("User logged out!");
            window.location = "../routes/index.php?page=home";
        </script>
        ';
}
?>